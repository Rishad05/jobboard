<?php (defined('BASEPATH')) or exit('No direct script access allowed'); ?>

<script src="<?= $assets ?>plugins/highchart/highcharts.js"></script>

<script src="<?= $assets ?>plugins/highchart/exporting.js"></script>

<script src="<?= $assets ?>plugins/chart.min.js"></script>



<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <?php
            // echo "<pre>";
            // print_r($this->session->userdata());
            // die;
            ?>
        </div>
    </div>

</section>